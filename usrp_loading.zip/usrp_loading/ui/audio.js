﻿/* Music 
======================================*/
var playlist = [
	{
		"song"    : "&quot;Pajak x Lara &quot; - Bella (Official Video)",
		"mp3"     : "https://www.youtube.com/watch?v=VgvupSwpjUY&ab_channel=UrbanRecords"
	},
	{
		"song"    : "&quot;Undefeated&quot; - Trevon Ricch (Prod. LOreal) 🎵 DMCA FREE",
		"mp3"     : "https://music.echorp.net/music/undefeated.mp3"
	},
	{
		"song"    : "&quot;new you!&quot; - aiko! 🎵 DMCA FREE",
		"mp3"     : "https://music.echorp.net/music/newyou.mp3"
	},
];

/* General Load / Variables
======================================*/
var duration;
var playPercent;
var bufferPercent;
var currentSong = Math.floor(Math.random() * playlist.length);
var next = document.getElementById("next");
var song = document.getElementById("song");
var timer = document.getElementById("timer");
var music = document.getElementById("music");
var volume = document.getElementById("volume");
var playButton = document.getElementById("play");
var timeline = document.getElementById("slider");
var playhead = document.getElementById("elapsed");
var previous = document.getElementById("previous");
var pauseButton = document.getElementById("pause");
var bufferhead = document.getElementById("buffered");
var timelineWidth = timeline.offsetWidth - playhead.offsetWidth;
var visablevolume = document.getElementsByClassName("volume")[0];

music.addEventListener("ended", _next, false);
music.addEventListener("timeupdate", timeUpdate, false);
music.addEventListener("progress", 	bufferUpdate, false);
load();

/* Functions
======================================*/
function load(){
	pauseButton.style.visibility = "hidden";
	song.innerHTML = playlist[currentSong]['song'];
	song.title = playlist[currentSong]['song'];
	music.innerHTML = '<source src="'+playlist[currentSong]['mp3']+'" type="audio/mp3">';
	music.load();
}

function reset(){ 
	rotate_reset = setInterval(function(){ 
		Rotate();
		if(rot == 0){
			clearTimeout(rotate_reset);
		}
	}, 1);
	fireEvent(pauseButton, 'click');
	playhead.style.width = "0px";
	bufferhead.style.width = "0px";
	timer.innerHTML = "0:00";
	music.innerHTML = "";
	currentSong = 0; // set to first song, to stay on last song: currentSong = playlist.length - 1;
	song.innerHTML = playlist[currentSong]['song'];
	song.title = playlist[currentSong]['song'];
	music.innerHTML = '<source src="'+playlist[currentSong]['mp3']+'" type="audio/mp3">';
	music.load();
}

function formatSecondsAsTime(secs, format) {
  var hr  = Math.floor(secs / 3600);
  var min = Math.floor((secs - (hr * 3600))/60);
  var sec = Math.floor(secs - (hr * 3600) -  (min * 60));
  if (sec < 10){ 
    sec  = "0" + sec;
  }
  return min + ':' + sec;
}

function timeUpdate() {
	bufferUpdate();
	playPercent = timelineWidth * (music.currentTime / duration);
	playhead.style.width = playPercent + "px";
	timer.innerHTML = formatSecondsAsTime(music.currentTime.toString());
}

function bufferUpdate() {
	music.onprogress = function(){
		bufferPercent = timelineWidth * (music.buffered.end(0) / duration);
		bufferhead.style.width = bufferPercent + "px";
	}
}

function fireEvent(el, etype){
	if (el.fireEvent) {
		el.fireEvent('on' + etype);
	} else {
		var evObj = document.createEvent('Events');
		evObj.initEvent(etype, true, false);
		el.dispatchEvent(evObj);
	}
}

function _next(){
	if(currentSong == playlist.length - 1){
		reset();
	} else {
		fireEvent(next, 'click');
	}
}

playButton.onclick = function() {
	music.play();
}

pauseButton.onclick = function() {
	music.pause();
}

music.addEventListener("play", function () {
	playButton.style.visibility = "hidden";
	pause.style.visibility = "visible";
}, false);

music.addEventListener("pause", function () {
	playButton.style.visibility = "visible";
	pause.style.visibility = "hidden";
}, false);

next.onclick = function(){
	playhead.style.width = "0px";
	bufferhead.style.width = "0px";
	timer.innerHTML = "0:00";
	music.innerHTML = "";
	if((currentSong + 1) == playlist.length){
		currentSong = 0;
		music.innerHTML = '<source src="'+playlist[currentSong]['mp3']+'" type="audio/mp3">';
	} else {
		currentSong++;
		music.innerHTML = '<source src="'+playlist[currentSong]['mp3']+'" type="audio/mp3">';
	}
	song.innerHTML = playlist[currentSong]['song'];
	song.title = playlist[currentSong]['song'];
	music.load();
	duration = music.duration;
	music.play();
}

previous.onclick = function(){
	playhead.style.width = "0px";
	bufferhead.style.width = "0px";
	timer.innerHTML = "0:00";
	music.innerHTML = "";
	if((currentSong - 1) == -1){
		currentSong = playlist.length - 1;
		music.innerHTML = '<source src="'+playlist[currentSong]['mp3']+'" type="audio/mp3">';
	} else {
		currentSong--;
		music.innerHTML = '<source src="'+playlist[currentSong]['mp3']+'" type="audio/mp3">';
	}
	song.innerHTML = playlist[currentSong]['song'];
	song.title = playlist[currentSong]['song'];
	music.load();
	duration = music.duration;
	music.play();
}

volume.oninput = function(){
	music.volume = volume.value;
	visablevolume.style.width = ((80 - 11) * volume.value) / 10 + "vh";
}

music.addEventListener("canplay", function () {
	duration = music.duration;
}, false);

const Images = [
	"https://media.discordapp.net/attachments/652157608668561419/863578415201779712/Screenshot_618.jpg?width=1164&height=552",
	"https://cdn.discordapp.com/attachments/652157608668561419/863577319298039848/Screenshot_643.png",
	"https://cdn.discordapp.com/attachments/652157608668561419/857706985557590076/jc1.jpg",
	"https://cdn.discordapp.com/attachments/652157608668561419/853868973849706566/swim.PNG",
	"https://cdn.discordapp.com/attachments/652157608668561419/853738892104957952/8dfad2fb21902e96e0611d3a8b1426ac.png",
	"https://cdn.discordapp.com/attachments/652157608668561419/853422529934524416/Screenshot_396.jpg",
	"https://cdn.discordapp.com/attachments/652157608668561419/852794380519866408/unknown.png",
	"https://cdn.discordapp.com/attachments/652157608668561419/852017542486949938/Screenshot_295.png",
	"https://cdn.discordapp.com/attachments/652157608668561419/851300358043336724/plane.png",
	"https://cdn.discordapp.com/attachments/652157608668561419/850179590923223071/218_20210604011157_1.png",
	"https://cdn.discordapp.com/attachments/652157608668561419/849800551872593930/dolphin.png",
	"https://cdn.discordapp.com/attachments/652157608668561419/846025245646389268/Screenshot_635.png",
	"https://cdn.discordapp.com/attachments/652157608668561419/828457613796573204/218_20210405033244_1.png",
	"https://cdn.discordapp.com/attachments/652157608668561419/828449951830769665/218_20210405030121_1.png",
	"https://cdn.discordapp.com/attachments/652157608668561419/861456002356215859/Screenshot_775.png",
	"https://cdn.discordapp.com/attachments/652157608668561419/858906765504937984/unknown.png",
	"https://cdn.discordapp.com/attachments/652157608668561419/858556790945087530/Screenshot_274.png",
	"https://cdn.discordapp.com/attachments/652157608668561419/857845669757976586/unknown.png",
	"https://cdn.discordapp.com/attachments/652157608668561419/855955060714373170/Screenshot_61.png",
	"https://cdn.discordapp.com/attachments/673934775400136749/864673243289747496/Screenshot_10.png",
	"https://i.imgur.com/Lh8NGKw.png",
	"https://cdn.discordapp.com/attachments/673934775400136749/862881248896745482/Rising_Dawn.png",
	"https://cdn.discordapp.com/attachments/673934775400136749/862860080977543168/image0.jpg",
	"https://cdn.discordapp.com/attachments/673934775400136749/861696576757563392/FiveM_b2060_GTAProcess_DI8SeOo6Tp.png",
	"https://cdn.discordapp.com/attachments/673934775400136749/860435102391992350/1.png",
]

window.onload = (event) => {
	music.play();
	music.volume = 0.3
	visablevolume.style.width = ((80 - 11) * 0.3) / 10 + "vh";
	document.getElementById("volume").value = "0.3"
	$(".background").css("background-image", `url(${Images[Math.floor(Math.random() * Images.length)]})`)
};