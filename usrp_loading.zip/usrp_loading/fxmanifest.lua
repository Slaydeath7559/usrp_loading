fx_version 'bodacious'
game 'gta5'

loadscreen_cursor "true"
loadscreen 'ui/index.html'

files {
    "ui/*.*",
}